/** \file robotnik_base_hw_lib.h
 * \author Robotnik Automation S.L.L.
 * \version 2.0
 * \date    2012
 *
 * \brief class for the RB1_base CAN multi-axis controller
 * 
 * (C) Robotnik Automation, SLL
 */

#include <cmath>
#include <cstdint>
#include <cstdlib>

#include <vector>

#include <ros/ros.h>
#include <std_msgs/Float32.h>               // battery, gyro, and steering angle
#include <std_msgs/Float64.h>               // battery, gyro, and steering angle
#include <std_msgs/Int32.h>               
#include <std_msgs/Bool.h>					// 
#include <sensor_msgs/JointState.h>

#include <robotnik_msgs/MotorStatus.h>

#include <robotnik_msgs/set_digital_output.h>

#include <self_test/self_test.h>
#include <diagnostic_msgs/DiagnosticStatus.h>
#include <diagnostic_updater/diagnostic_updater.h>
#include <diagnostic_updater/update_functions.h>
#include <diagnostic_updater/DiagnosticStatusWrapper.h>
#include <diagnostic_updater/publisher.h>

#include <robotnik_base_hw_lib/Component.h>
#include <robotnik_base_hw_lib/MotorPosition.h>
#include <robotnik_base_hw_lib/MotorVelocity.h>
#include <robotnik_msgs/SetMotorStatus.h>
#include <robotnik_msgs/inputs_outputs.h>


//ROS_CONTROL includes
#include <hardware_interface/robot_hw.h>
#include <hardware_interface/joint_state_interface.h>
#include <hardware_interface/joint_command_interface.h>
#include <hardware_interface/actuator_state_interface.h>
#include <hardware_interface/actuator_command_interface.h>
#include <controller_manager/controller_manager.h>

#include <joint_limits_interface/joint_limits.h>
#include <joint_limits_interface/joint_limits_interface.h>
#include <joint_limits_interface/joint_limits_rosparam.h>
#include <joint_limits_interface/joint_limits_urdf.h>

#include <urdf/model.h>

#define MAX_CTRL_PARAMS         9

#define MAX_SEC_ELEVATOR_MOVING 10

struct Joint{
    double position;
    double velocity;
    double effort;
    double command;
};

class RobotnikBaseHW: public hardware_interface::RobotHW, public Component
{
    private:
        self_test::TestRunner self_test_;
        ros::NodeHandle node_handle_;
        ros::NodeHandle private_node_handle_;
        double desired_freq_;
        diagnostic_updater::Updater diagnostic_;					 	// General status diagnostic updater
        
        //! Topic to publish the current motor counts
        ros::Publisher pub_status_;  

        ros::Publisher battery_pub_;
        ros::Publisher estop_pub_;
        ros::Publisher battery_alarm_pub_;
	ros::Publisher io_pub_;

        // Services
        ros::ServiceServer set_motor_status_;
        ros::ServiceServer set_digital_output_;

        //! Can device port
        string can_dev_;
        //! CAN device
        PCan *can_device_;
        //! motor for steering
        std::vector<MotorPosition *> motor_position_;
        std::vector<MotorVelocity *> motor_velocity_;

        std::vector<int> motor_position_can_id_;
        std::vector<int> motor_velocity_can_id_;

        std::vector<int> motor_spin_;

        std::vector<std::string> joint_position_name_;
        std::vector<std::string> joint_velocity_name_;
        std::vector<std::string> joint_name_;

        std::vector<std::string> joint_type_;

        std::vector<int> joint_can_id_;
        std::vector<int> joint_offset_;
        std::vector<int> joint_spin_;

        std::vector<kinematic_params> kin_par_vector_;

        double wheel_diameter_;
        double gearbox_ratio_;
        bool has_encoder_;
        double encoder_factor_;
    
	int num_inputs_per_driver_;
    	int num_outputs_per_driver_;

        bool has_elevator_;

        double elevator_high_pos_;
        double elevator_low_pos_;
        string joint_elevator_name_;
        int elevator_digital_output_high_;
        int elevator_digital_output_low_;
        int elevator_digital_input_high_;
        int elevator_digital_input_low_;
        
        //elevator management
		bool elevator_movement_;
		ros::Time begin_elevator_move_time_;

        bool elevator_high_;

        //! Voltage level to raise an alarm
        double battery_alarm_voltage_;


        bool running;
        //! Flag to set the status of can comm
        bool can_communication;
        //! Saves the time of the last command received
        ros::Time last_command_time;

        int publish_status_counter;
        int publish_status_freq; // number of loop cycles to publish the status

        // ROS CONTROL STUFF
        hardware_interface::JointStateInterface joint_state_interface_;
        hardware_interface::PositionJointInterface position_joint_interface_;
        hardware_interface::VelocityJointInterface velocity_joint_interface_;
  
        joint_limits_interface::PositionJointSaturationInterface position_joint_sat_limits_interface_;
        joint_limits_interface::VelocityJointSaturationInterface velocity_joint_sat_limits_interface_;

        // Joint limits interfaces - Soft limits
        joint_limits_interface::PositionJointSoftLimitsInterface position_joint_soft_limits_interface_;
        joint_limits_interface::VelocityJointSoftLimitsInterface velocity_joint_soft_limits_interface_;
        
        std::vector<Joint> joint_position_;
        std::vector<Joint> joint_velocity_;

        Joint *joint_elevator_;

        urdf::Model *urdf_model_;
        std::string urdf_model_as_string_;

        std::string name_; //TODO set node name
        bool use_rosparam_joint_limits_, use_soft_limits_if_available_; //TODO read from params

        ros::Duration recovery_attempt_period_; // period between recovery attempts
        ros::Time last_recovery_attempt_time_;  // timestamp of last recovery attempt
public:

        RobotnikBaseHW(ros::NodeHandle h);

        /*!	\fn RobotnikBaseHW::~RobotnikBaseHW()
         * 	\brief Public destructor
         */
        ~RobotnikBaseHW();

        /*!	\fn int RobotnikBaseHW::start()
         * 	\brief Start Controller
         */
        //int start();

        /*!	\fn RobotnikBaseHW::stop()
         * 	\brief Stop Controller
         */
        //int stop();
        
        // Component Stuff
		Component::ReturnValue Setup();
		
		Component::ReturnValue ShutDown();
		
		Component::ReturnValue Start();
		
		Component::ReturnValue Stop();

        void InitState();
        void StandbyState();
        void ReadyState();
        void EmergencyState();
        void FailureState();
        void RestartState();
        void AllState();

        Component::ReturnValue update();

        int home();

        int sendToHome();

        bool isHomed();
   
        int waitToBeReady();

        int setMotorsToRunningFrequency();
		//! disables the motors (quick stop)
        void disableMotors();
        //! enables the motors (operation enabled)
        void enableMotors();

        void sendZeroToMotors();

        /*!	\fn RobotnikBaseHW::connectTest()
         * 	\brief Test to connect to Motors
         */
        void connectTest(diagnostic_updater::DiagnosticStatusWrapper& status);

        /*
         *\brief Checks the status of the controller. Diagnostics
         *
         */
        void controllerDiagnostic(diagnostic_updater::DiagnosticStatusWrapper &stat);

        /*! \fn void controllerStatusPublishing()
         * \brief Publish Motors Status Topics
         *
         */
        void controllerStatusPublishing();

        ////////////////////////////////////////////////////////////////////////
        // PUBLIC FUNCTIONS

        /*!	\fn void RobotnikBaseHW::toggleMotorPower(unsigned char val)
         *	\brief Switches on/off the motor
         */
        void toggleMotorPower(unsigned char val);

        /*! \fn int readCANMessages()
         *	\brief Read messages from CAN bus
         *	\return -1 if ERROR
         *	\return 0 if OK
         */
        int readCANMessages();


        // Method readAndPublish()
        int readAndPublish();

        bool spin();

        /*! \fn  bool setMotorStatus(RobotnikBaseHW::SetMotorStatus::Request &req, RobotnikBaseHW::SetMotorStatus::Response &res )
         * Sets the odometry of the robot
         */
        bool setMotorStatus(robotnik_msgs::SetMotorStatus::Request &req, robotnik_msgs::SetMotorStatus::Response &res );

		// Set Motor Digital Output        
		bool setDigitalOutput(int number, bool value );  
		  
        // Set Motor Digital Output
        bool srvCallback_SetDigitalOutput(robotnik_msgs::set_digital_output::Request &request, robotnik_msgs::set_digital_output::Response &response );

        // Get Digital Output status by number
        bool GetDigitalOutput(int iOutput);
		
		// Get Digital Input status by number
        bool GetDigitalInput(int iInput);

        /*! \fn  double encoderCountsToAngle(int counts)
         *  Converts absolute encoder counts into angle
         *  \return converted angle in radians
         */
        double encoderCountsToAngle(int counts);

        // ROS_CONTROL STUFF
        /** \brief Read the state from the robot hardware. */
        void read(ros::Duration &elapsed_time);

        /** \brief write the command to the robot hardware. */
        void write(ros::Duration &elapsed_time);

    	void enforceLimits(ros::Duration &period);

        void initHardwareInterface();

        void loadURDF(ros::NodeHandle &nh, std::string param_name);

        bool registerJointLimits(const urdf::Model *urdf_model, const std::string &joint_name, const hardware_interface::JointHandle &joint_handle);
		

};

