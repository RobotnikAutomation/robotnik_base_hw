
#include <robotnik_msgs/BatteryStatus.h>
#include <std_msgs/Bool.h>

class BatteryEstimation {
  private:
    float A_discharging,B_discharging,C_discharging, A_charging,B_charging,
        values_charging, values_discharging,
        max_discharging, min_discharging, 
        max_charging, min_charging, batteryArray[200];
    int averageSize, actual;
    bool charging;
    ros::Subscriber sub_;
    ros::NodeHandle nh_;
  public:
    BatteryEstimation();
    BatteryEstimation(ros::NodeHandle nh);
    float return_percentage(float voltage);
    void roll(float *batteryArray);
    void setCharge(bool value);
    float battery_average(float *batteryArray);
    robotnik_msgs::BatteryStatus battery_info (float voltage);
};
