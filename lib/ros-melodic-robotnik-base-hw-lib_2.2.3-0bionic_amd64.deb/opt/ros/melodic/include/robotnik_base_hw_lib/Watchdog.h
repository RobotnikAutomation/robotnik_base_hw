#ifndef _ROBOTNIK_BASE_HW_WATCHDOG_
#define _ROBOTNIK_BASE_HW_WATCHDOG_

#include <robotnik_base_hw_lib/TimeCounter.h>
#include <ros/ros.h>

class Watchdog
{
public:
  Watchdog(ros::WallDuration duration, std::string id)
  {
    duration_ = duration;
    id_ = id;
  }

  Watchdog(double duration, std::string id = "") : Watchdog(ros::WallDuration(duration), id)
  {
  }

  Watchdog() : Watchdog(ros::WallDuration(), "")
  {
  }

  void reset()
  {
    started_ = true;
    time_counter_.tic();
  }

  void stop()
  {
    started_ = false;
  }

  bool isRunning()
  {
    return started_;
  }

  bool timedout()
  {
    if (not started_)
    {
      ROS_DEBUG_STREAM_NAMED("watchdog-" + id_, "timedout: " << false << " (not started)");
      return false;
    }
    bool auto_start = false;
    time_counter_.toc(auto_start);

    ros::WallDuration time_elapsed_since_reset = time_counter_.durationElapsed();

    bool timedout = (duration_ < time_elapsed_since_reset);
    if (timedout == true)
    {
      ROS_DEBUG_STREAM_NAMED("watchdog-" + id_, "timedout: " << timedout << ", duration: " << duration_
                                                             << ", elapsed: " << time_elapsed_since_reset.toSec());
    }
    return timedout;
  }

  double getSeconds()
  {
    return duration_.toSec();
  }

  ros::WallDuration getDuration()
  {
    return duration_;
  }

  std::string getID()
  {
    return id_;
  }

private:
  ros::WallDuration duration_;

  TimeCounter time_counter_;
  bool started_;
  std::string id_;
};

#endif  // _ROBOTNIK_BASE_HW_WATCHDOG_
