/** \file robotnik_base_hw_lib.h
 * \author Robotnik Automation S.L.L.
 * \version 2.0
 * \date    2012
 *
 * \brief class for the RB1_base CAN multi-axis controller
 *
 * (C) Robotnik Automation, SLL
 */

#ifndef _ROBOTNIK_BASE_HW_ROBOTNIK_BASE_HW_H_
#define _ROBOTNIK_BASE_HW_ROBOTNIK_BASE_HW_H_

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <vector>
#include <XmlRpcException.h>

#include <ros/ros.h>
#include <std_msgs/Float32.h>  // gyro, and steering angle
#include <std_msgs/Float64.h>  // gyro, and steering angle
#include <std_msgs/Int32.h>
#include <std_msgs/Bool.h>
#include <std_msgs/String.h>
#include <std_srvs/Trigger.h>
#include <std_srvs/SetBool.h>
#include <sensor_msgs/JointState.h>

#include <self_test/self_test.h>
#include <diagnostic_msgs/DiagnosticStatus.h>
#include <diagnostic_updater/diagnostic_updater.h>
#include <diagnostic_updater/update_functions.h>
#include <diagnostic_updater/DiagnosticStatusWrapper.h>
#include <diagnostic_updater/publisher.h>

#include <robotnik_base_hw_lib/Component.h>
#include <robotnik_base_hw_lib/MotorDrive.h>
#include <robotnik_base_hw_lib/MotorDriveA.h>
#include <robotnik_base_hw_lib/MotorDriveI.h>
#include <robotnik_base_hw_lib/MotorDriveN.h>
#include <robotnik_msgs/RobotnikMotorsStatus.h>
#include <robotnik_msgs/MotorStatus.h>
#include <robotnik_msgs/State.h>
#include <robotnik_msgs/SetMotorStatus.h>
#include <robotnik_msgs/inputs_outputs.h>
#include <robotnik_msgs/set_digital_output.h>
#include <robotnik_msgs/SetMotorPID.h>
#include <robotnik_msgs/SetString.h>
#include <robotnik_msgs/SetCurrent.h>
#include <robotnik_msgs/WatchdogStatus.h>
#include <robotnik_msgs/WatchdogStatusArray.h>
#include <robotnik_msgs/MotorReferenceValueArray.h>
#include <robotnik_msgs/MotorReferenceValue.h>
#include <robotnik_msgs/StringArray.h>

// ROS_CONTROL includes
#include <hardware_interface/robot_hw.h>
#include <hardware_interface/joint_state_interface.h>
#include <hardware_interface/joint_command_interface.h>
#include <hardware_interface/actuator_state_interface.h>
#include <hardware_interface/actuator_command_interface.h>
#include <controller_manager/controller_manager.h>

#include <joint_limits_interface/joint_limits.h>
#include <joint_limits_interface/joint_limits_interface.h>
#include <joint_limits_interface/joint_limits_rosparam.h>
#include <joint_limits_interface/joint_limits_urdf.h>

#include <urdf/model.h>

#define MAX_CTRL_PARAMS 9

#define ROBOTNIK_INIT_HZ 1.0             // motor component frequency during init
#define ROBOTNIK_DEFAULT_HZ 50.0         // motor component frequency during running
#define MAX_NUMBER_OF_READ_CAN_MSGS 100  // max number read per iteration

using namespace robotnik_base_hw_lib;

struct Joint
{
  double position;
  double velocity;
  double effort;
  double command;
};

struct PID
{
  std::string name;
  int can_id;
  double kp;
  double ki;
  double kd;
};

class RobotnikBaseHW : public hardware_interface::RobotHW, public Component
{
private:
  self_test::TestRunner self_test_;
  ros::NodeHandle node_handle_;
  ros::NodeHandle private_node_handle_;
  double desired_freq_;
  diagnostic_updater::Updater diagnostic_;  // General status diagnostic updater

  //! Topic to publish the current motor counts
  ros::Publisher component_state_pub_;
  ros::Publisher motor_status_pub_;
  ros::Publisher battery_voltage_pub_;
  ros::Publisher estop_pub_;
  ros::Publisher estop_by_input_pub_;
  ros::Publisher io_pub_;
  ros::Publisher vel_pid_pub_;
  ros::Publisher available_pid_pub_;
  std::vector<ros::Publisher> motor_status_vector_pub_;           // array for independent motor publisher
  std::vector<ros::Publisher> motor_watchdog_status_vector_pub_;  // array for independent motor watchdog_status
                                                                  // publsiher
  std::vector<ros::Publisher> motor_reference_value_vector_pub_;  // array for independent motor command reference
                                                                  // publisher
  std::vector<ros::Publisher> motor_error_pub_;                   // array for independent motor errors publisher

  // Services
  ros::ServiceServer set_motor_status_;
  ros::ServiceServer set_digital_output_;
  ros::ServiceServer send_to_home_;
  ros::ServiceServer set_velocity_pid_;
  ros::ServiceServer set_current_;
  ros::ServiceServer set_pid;
  ros::ServiceServer enabled_op_motors_;  // Set motors to be in OPERATION_ENABLED
  ros::ServiceServer quickstop_motors;    // Set motors to be in QUICK_STOP

  //! Can device port
  std::string can_dev_;
  //! CAN device
  PCan* can_device_;
  //! motor for steering
  std::vector<MotorDrive*> motor_;
  std::vector<MotorDrive*> motor_position_;
  std::vector<MotorDrive*> motor_velocity_;

  std::vector<int> motor_can_id_;
  std::vector<int> motor_position_can_id_;
  std::vector<int> motor_velocity_can_id_;

  std::vector<int> motor_spin_;

  std::vector<std::string> joint_position_name_;
  std::vector<std::string> joint_velocity_name_;
  std::vector<std::string> joint_name_;
  // pos, vel
  std::vector<std::string> joint_type_;
  // motordrive model: A, I, N
  std::vector<std::string> joint_model_;

  std::vector<int> joint_can_id_;
  std::vector<int> joint_offset_;
  std::vector<int> joint_spin_;
  std::vector<double> joint_gearbox_ratio_;
  std::vector<bool> joint_home_required_;
  int home_method_;
  std::vector<bool> joint_home_at_startup_;
  std::vector<int> low_position_limit_;
  std::vector<int> high_position_limit_;

  // Digital-Analog Driver Inputs-Outputs
  std::vector<int> joint_inputs_per_driver_;
  std::vector<int> joint_outputs_per_driver_;
  std::vector<int> joint_analog_inputs_per_driver_;

  // Potentiometer digital input number (just for MotorPositionPotentiometer type)
  std::vector<int> joint_potentiometer_analog_input_;
  // Potentiometer voltage calibration (just for MotorPositionPotentiometer type)
  std::vector<double> joint_potentiometer_voltage_calibration_;

  // Flag to disable the continous motor consumption
  std::vector<double> control_power_consumption_;

  // specific encoder resolution per joint/motor
  std::vector<double> joint_encoder_resolution_;

  //! kinematic control parameters
  std::vector<MotorDrive::KinematicParams> kinematic_params_;

  //! IoParams control parameters
  std::vector<MotorDrive::IoParams> io_params_;

  //! control parameters
  MotorDrive::ControlParams control_params_;

  bool calculate_vel_using_pose_;
  double wheel_diameter_;
  double gearbox_ratio_;
  bool has_encoder_;
  double encoder_resolution_;
  bool check_hit_position_limit_;

  int digital_input_estop_;
  bool ignore_has_absolute_position_valid_;

  // Timeout for disabling motors if no target is received
  double command_velocity_timeout_;

  bool running;
  //! Flag to set the status of can comm
  bool can_communication;
  //! Saves the time of the last command received
  ros::Time last_command_time_;
  //! flag active when no target commands received
  bool last_command_timed_out_;
  //! flag to apply the drive status command based on last command received
  bool apply_drive_status_control_;

  int publish_status_counter;
  int publish_status_freq;  // number of loop cycles to publish the status

  // ROS CONTROL STUFF
  hardware_interface::JointStateInterface joint_state_interface_;
  hardware_interface::PositionJointInterface position_joint_interface_;
  hardware_interface::VelocityJointInterface velocity_joint_interface_;

  joint_limits_interface::PositionJointSaturationInterface position_joint_sat_limits_interface_;
  joint_limits_interface::VelocityJointSaturationInterface velocity_joint_sat_limits_interface_;

  // Joint limits interfaces - Soft limits
  joint_limits_interface::PositionJointSoftLimitsInterface position_joint_soft_limits_interface_;
  joint_limits_interface::VelocityJointSoftLimitsInterface velocity_joint_soft_limits_interface_;

  std::vector<Joint> joint_position_;
  std::vector<Joint> joint_velocity_;

  boost::shared_ptr<urdf::Model> urdf_model_;
  std::string urdf_model_as_string_;

  std::string name_;                                               // TODO set node name
  bool use_rosparam_joint_limits_, use_soft_limits_if_available_;  // TODO read from params

  ros::Duration recovery_attempt_period_;  // period between recovery attempts
  ros::Time last_recovery_attempt_time_;   // timestamp of last recovery attempt
  robotnik_msgs::inputs_outputs io_;       // global inputs/outputs gathering all the drives
  std::vector<double> k_multiplier_;       // k multiplier for analog inputs

  bool e_stop_, e_stop_by_input_;

  std::vector<double> battery_voltage_raw_vector;  // current input in volts
  std::vector<double> battery_voltage_vector;      // filtered input in volts
  int battery_voltage_raw_index = 0;               // index of the vector
  double k_battery_voltage_offset_;  // Offset applied to the battery read from the motordrive. (Calculated REAL
                                     // MEASUREMENT - MOTORDRIVE OUTPUT)

  // Multiple PID Sets
  bool using_multiple_pid_sets_;
  XmlRpc::XmlRpcValue pids;
  std::vector<PID> pid_vector;
  std::string current_pid;

  bool setVelocityPidModeSrvCallback(robotnik_msgs::SetString::Request& request,
                                     robotnik_msgs::SetString::Response& response);

public:
  RobotnikBaseHW(ros::NodeHandle h);

  /*!	\fn RobotnikBaseHW::~RobotnikBaseHW()
   * 	\brief Public destructor
   */
  ~RobotnikBaseHW();

  /*!	\fn int RobotnikBaseHW::start()
   * 	\brief Start Controller
   */
  // int start();

  /*!	\fn RobotnikBaseHW::stop()
   * 	\brief Stop Controller
   */
  // int stop();

  // Component Stuff
  Component::ReturnValue Setup();

  Component::ReturnValue ShutDown();

  Component::ReturnValue Start();

  Component::ReturnValue Stop();

  void InitState();
  void StandbyState();
  void ReadyState();
  void EmergencyState();
  void FailureState();
  void RestartState();
  void AllState();

  Component::ReturnValue update();

  int waitToBeReady();

  bool InitSystem();

  bool IsSystemReady();

  bool HasToHome();

  bool SendToHome(bool force_home);

  bool IsHomed();

  int setMotorsToRunningFrequency();
  //! disables the motors (quick stop)
  void setMotorToQuickStop();
  //! enables the motors (operation enabled)
  void setMotorToOpEnabled();

  void sendZeroToMotors();

  /*!	\fn RobotnikBaseHW::connectTest()
   * 	\brief Test to connect to Motors
   */
  void connectTest(diagnostic_updater::DiagnosticStatusWrapper& status);

  /*
   *\brief Checks the status of the controller. Diagnostics
   *
   */
  void controllerDiagnostic(diagnostic_updater::DiagnosticStatusWrapper& stat);

  /*! \fn void controllerStatusPublishing()
   * \brief Publish Motors Status Topics
   *
   */
  void controllerStatusPublishing();

  ////////////////////////////////////////////////////////////////////////
  // PUBLIC FUNCTIONS

  /*!	\fn void RobotnikBaseHW::toggleMotorPower(unsigned char val)
   *	\brief Switches on/off the motor
   */
  void toggleMotorPower(unsigned char val);

  /*! \fn int readCANMessages()
   *	\brief Read messages from CAN bus
   *	\return -1 if ERROR
   *	\return 0 if OK
   */
  int readCANMessages();

  // Method readAndPublish()
  int readAndPublish();

  bool spin();

  /*! \fn  bool setMotorStatus(RobotnikBaseHW::SetMotorStatus::Request &req, RobotnikBaseHW::SetMotorStatus::Response
   * &res )
   * Sets the odometry of the robot
   */
  bool setMotorStatus(robotnik_msgs::SetMotorStatus::Request& req, robotnik_msgs::SetMotorStatus::Response& res);

  // Set Motor Digital Output
  bool setDigitalOutput(uint number, bool value);

  // Set Motor Digital Output
  bool setDigitalOutputSrvCallback(robotnik_msgs::set_digital_output::Request& request,
                                   robotnik_msgs::set_digital_output::Response& response);

  bool sendToHomeSrvCallback(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response);

  // Get Digital Output status by number
  bool getDigitalOutput(uint iOutput);

  // Get Digital Input status by number
  bool getDigitalInput(uint iInput);
  // Get Analog Input status by number
  double getAnalogInput(uint iInput);

  /*! \fn  double encoderCountsToAngle(int counts)
   *  Converts absolute encoder counts into angle
   *  \return converted angle in radians
   */
  double encoderCountsToAngle(int counts);

  // ROS_CONTROL STUFF
  /** \brief Read the state from the robot hardware. */
  void read(ros::Duration& elapsed_time);

  /** \brief write the command to the robot hardware. */
  void write(ros::Duration& elapsed_time);

  void enforceLimits(ros::Duration& period);
  void resetLimits();

  void initHardwareInterface();

  void loadURDF(ros::NodeHandle& nh, std::string param_name);

  bool registerJointLimits(const boost::shared_ptr<urdf::Model> urdf_model, const std::string& joint_name,
                           const hardware_interface::JointHandle& joint_handle);

  bool RestartCan();
  void createMotorDrives();
  void destroyMotorDrives();
  bool setVelocityPidSrvCallback(robotnik_msgs::SetMotorPID::Request& request,
                                 robotnik_msgs::SetMotorPID::Response& response);
  bool setCurrentSrvCallback(robotnik_msgs::SetCurrent::Request& request,
                             robotnik_msgs::SetCurrent::Response& response);

  bool enabledOpMotorsSrvCallback(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response);
  bool quickstopMotorsSrvCallback(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response);

  // Performs battery state and battery docking control
  void batteryControl();
  // processes battery raw values from driver
  void processBatteryVoltageRaw(double value);
  // gets the processed battery voltage
  double getBatteryVoltage();

  // Check that target velocity commands have been received
  void driveStatusControl();

public:
  bool isEStopEnabled();
  bool isEStopByInputEnabled();

  bool isSafetyEnabled();
};

#endif  // _ROBOTNIK_BASE_HW_ROBOTNIK_BASE_HW_H_
