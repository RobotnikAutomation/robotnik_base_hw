; Auto-generated. Do not edit!


(cl:in-package robotnik_msgs-msg)


;//! \htmlinclude Interval.msg.html

(cl:defclass <Interval> (roslisp-msg-protocol:ros-message)
  ((init_value
    :reader init_value
    :initarg :init_value
    :type cl:float
    :initform 0.0)
   (end_value
    :reader end_value
    :initarg :end_value
    :type cl:float
    :initform 0.0)
   (step_size
    :reader step_size
    :initarg :step_size
    :type cl:float
    :initform 0.0))
)

(cl:defclass Interval (<Interval>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Interval>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Interval)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name robotnik_msgs-msg:<Interval> is deprecated: use robotnik_msgs-msg:Interval instead.")))

(cl:ensure-generic-function 'init_value-val :lambda-list '(m))
(cl:defmethod init_value-val ((m <Interval>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robotnik_msgs-msg:init_value-val is deprecated.  Use robotnik_msgs-msg:init_value instead.")
  (init_value m))

(cl:ensure-generic-function 'end_value-val :lambda-list '(m))
(cl:defmethod end_value-val ((m <Interval>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robotnik_msgs-msg:end_value-val is deprecated.  Use robotnik_msgs-msg:end_value instead.")
  (end_value m))

(cl:ensure-generic-function 'step_size-val :lambda-list '(m))
(cl:defmethod step_size-val ((m <Interval>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robotnik_msgs-msg:step_size-val is deprecated.  Use robotnik_msgs-msg:step_size instead.")
  (step_size m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Interval>) ostream)
  "Serializes a message object of type '<Interval>"
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'init_value))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'end_value))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'step_size))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Interval>) istream)
  "Deserializes a message object of type '<Interval>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'init_value) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'end_value) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'step_size) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Interval>)))
  "Returns string type for a message object of type '<Interval>"
  "robotnik_msgs/Interval")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Interval)))
  "Returns string type for a message object of type 'Interval"
  "robotnik_msgs/Interval")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Interval>)))
  "Returns md5sum for a message object of type '<Interval>"
  "3c72591f88118e59cc12eac4c450f889")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Interval)))
  "Returns md5sum for a message object of type 'Interval"
  "3c72591f88118e59cc12eac4c450f889")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Interval>)))
  "Returns full string definition for message of type '<Interval>"
  (cl:format cl:nil "float64 init_value~%float64 end_value~%float64 step_size~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Interval)))
  "Returns full string definition for message of type 'Interval"
  (cl:format cl:nil "float64 init_value~%float64 end_value~%float64 step_size~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Interval>))
  (cl:+ 0
     8
     8
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Interval>))
  "Converts a ROS message object to a list"
  (cl:list 'Interval
    (cl:cons ':init_value (init_value msg))
    (cl:cons ':end_value (end_value msg))
    (cl:cons ':step_size (step_size msg))
))
