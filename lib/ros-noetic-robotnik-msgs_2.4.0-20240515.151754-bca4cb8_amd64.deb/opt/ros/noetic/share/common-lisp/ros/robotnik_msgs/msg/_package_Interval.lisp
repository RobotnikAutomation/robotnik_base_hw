(cl:in-package robotnik_msgs-msg)
(cl:export '(INIT_VALUE-VAL
          INIT_VALUE
          END_VALUE-VAL
          END_VALUE
          STEP_SIZE-VAL
          STEP_SIZE
))