(cl:in-package robotnik_msgs-srv)
(cl:export '(OUTPUT-VAL
          OUTPUT
          DURATION-VAL
          DURATION
          HIGH-VAL
          HIGH
          RET-VAL
          RET
))